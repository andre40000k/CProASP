﻿namespace CProASP.Transport
{
    public class BaseTransport
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public double Speed { get; set; }
        public double Weight { get; set; }
        public string Status { get; set; }
    }
}
